"""Module for wiring game routes into Flask app."""

from flask import Flask

from domain.service.game_service import GameService
from web.route.game_route import build_game_blueprint


def register_game_module(app: Flask, game_service: GameService) -> None:
    """Register game HTTP routes."""

    app.register_blueprint(build_game_blueprint(game_service))
