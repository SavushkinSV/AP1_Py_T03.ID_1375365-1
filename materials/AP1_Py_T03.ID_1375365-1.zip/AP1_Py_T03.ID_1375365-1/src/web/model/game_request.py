"""Input model from HTTP request."""

from dataclasses import dataclass


@dataclass(frozen=True)
class CurrentGameRequest:
    """Incoming web model of game board."""

    board: list[list[int]]
