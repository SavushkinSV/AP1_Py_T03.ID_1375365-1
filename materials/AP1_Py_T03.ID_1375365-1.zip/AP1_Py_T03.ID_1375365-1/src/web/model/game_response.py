"""Output model for HTTP response."""

from dataclasses import dataclass


@dataclass(frozen=True)
class CurrentGameResponse:
    """Outgoing web model with game state."""

    game_id: str
    board: list[list[int]]
    is_finished: bool
    winner: int | None
    message: str
