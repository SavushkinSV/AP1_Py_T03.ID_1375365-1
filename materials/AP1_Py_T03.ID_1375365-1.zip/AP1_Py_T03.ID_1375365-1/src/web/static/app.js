(() => {
  const EMPTY = 0;
  const USER = 1;
  const COMPUTER = 2;

  /** @type {number[][]} */
  let board = emptyBoard();
  let gameId = "";
  let busy = false;
  let gameOver = false;
  /** Победитель при завершении: 1, 2 или null (ничья). */
  let endWinner = null;

  const boardEl = document.getElementById("board");
  const boardWrap = boardEl.closest(".board-wrap");
  const winLineSvg = document.getElementById("win-line");
  const statusEl = document.getElementById("status");
  const newBtn = document.getElementById("new-game");

  function emptyBoard() {
    return [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
    ];
  }

  function copyBoard(b) {
    return b.map((row) => row.slice());
  }

  /**
   * @param {number[][]} b
   * @param {number} winner
   * @returns {[[number, number], [number, number], [number, number]] | null}
   */
  function findWinningTriple(b, winner) {
    for (let r = 0; r < 3; r++) {
      if (b[r][0] === winner && b[r][1] === winner && b[r][2] === winner) {
        return [
          [r, 0],
          [r, 1],
          [r, 2],
        ];
      }
    }
    for (let c = 0; c < 3; c++) {
      if (b[0][c] === winner && b[1][c] === winner && b[2][c] === winner) {
        return [
          [0, c],
          [1, c],
          [2, c],
        ];
      }
    }
    if (b[0][0] === winner && b[1][1] === winner && b[2][2] === winner) {
      return [
        [0, 0],
        [1, 1],
        [2, 2],
      ];
    }
    if (b[0][2] === winner && b[1][1] === winner && b[2][0] === winner) {
      return [
        [0, 2],
        [1, 1],
        [2, 0],
      ];
    }
    return null;
  }

  function extendSegment(x1, y1, x2, y2, extra) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len;
    const uy = dy / len;
    const pad = Math.min(extra, len * 0.12);
    return {
      x1: x1 - ux * pad,
      y1: y1 - uy * pad,
      x2: x2 + ux * pad,
      y2: y2 + uy * pad,
    };
  }

  function updateWinLine() {
    winLineSvg.innerHTML = "";
    if (!boardWrap || !gameOver || endWinner == null) {
      return;
    }
    const triple = findWinningTriple(board, endWinner);
    if (!triple) {
      return;
    }

    const cells = boardEl.children;
    const [a, , c] = triple;
    const elA = cells[a[0] * 3 + a[1]];
    const elC = cells[c[0] * 3 + c[1]];
    if (!elA || !elC) {
      return;
    }

    const wrapRect = boardWrap.getBoundingClientRect();
    const ar = elA.getBoundingClientRect();
    const cr = elC.getBoundingClientRect();
    let x1 = ar.left + ar.width / 2 - wrapRect.left;
    let y1 = ar.top + ar.height / 2 - wrapRect.top;
    let x2 = cr.left + cr.width / 2 - wrapRect.left;
    let y2 = cr.top + cr.height / 2 - wrapRect.top;
    const ext = extendSegment(x1, y1, x2, y2, 14);
    x1 = ext.x1;
    y1 = ext.y1;
    x2 = ext.x2;
    y2 = ext.y2;

    winLineSvg.setAttribute("width", String(wrapRect.width));
    winLineSvg.setAttribute("height", String(wrapRect.height));
    winLineSvg.setAttribute("viewBox", `0 0 ${wrapRect.width} ${wrapRect.height}`);

    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", String(x1));
    line.setAttribute("y1", String(y1));
    line.setAttribute("x2", String(x2));
    line.setAttribute("y2", String(y2));
    line.setAttribute(
      "class",
      endWinner === USER ? "win-stroke win-stroke--user" : "win-stroke win-stroke--computer",
    );
    winLineSvg.appendChild(line);
  }

  function setStatus(text, isError = false) {
    statusEl.textContent = text;
    statusEl.classList.toggle("error", isError);
  }

  function render() {
    boardEl.innerHTML = "";
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        const v = board[r][c];
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "cell";
        if (v === USER) {
          btn.textContent = "✕";
          btn.classList.add("user");
        } else if (v === COMPUTER) {
          btn.textContent = "○";
          btn.classList.add("computer");
        } else {
          btn.textContent = "";
        }
        const canPlay =
          !busy &&
          !gameOver &&
          v === EMPTY &&
          gameId;
        btn.disabled = !canPlay;
        btn.addEventListener("click", () => onCellClick(r, c));
        boardEl.appendChild(btn);
      }
    }
    requestAnimationFrame(() => updateWinLine());
  }

  if (boardWrap && typeof ResizeObserver !== "undefined") {
    const ro = new ResizeObserver(() => {
      if (gameOver && endWinner != null) {
        updateWinLine();
      }
    });
    ro.observe(boardWrap);
  }

  async function postGame(nextBoard) {
    const res = await fetch(`/game/${gameId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ board: nextBoard }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error || `Ошибка ${res.status}`;
      throw new Error(msg);
    }
    return data;
  }

  async function onCellClick(row, col) {
    if (busy || gameOver || board[row][col] !== EMPTY || !gameId) return;

    const next = copyBoard(board);
    next[row][col] = USER;

    busy = true;
    gameOver = false;
    endWinner = null;
    render();
    setStatus("Отправка хода…");

    try {
      const data = await postGame(next);
      board = data.board;
      gameOver = data.is_finished;
      endWinner = data.is_finished ? (data.winner ?? null) : null;
      if (gameOver) {
        setStatus(data.message || "Игра завершена.");
      } else {
        setStatus(data.message || "Ваш ход — выберите пустую клетку.");
      }
    } catch (e) {
      setStatus(e.message || String(e), true);
    } finally {
      busy = false;
      render();
    }
  }

  function newGame() {
    gameId = crypto.randomUUID();
    board = emptyBoard();
    busy = false;
    gameOver = false;
    endWinner = null;
    winLineSvg.innerHTML = "";
    setStatus("Сделайте первый ход (клик по пустой клетке).");
    render();
  }

  newBtn.addEventListener("click", newGame);
  newGame();
})();
