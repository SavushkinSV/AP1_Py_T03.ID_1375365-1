"""HTTP routes for game operations."""

from dataclasses import asdict
from http import HTTPStatus
from uuid import UUID

from flask import Blueprint, jsonify, request

from domain.service.game_service import GameService
from web.mapper.game_mapper import WebGameMapper
from web.model.game_request import CurrentGameRequest


def build_game_blueprint(game_service: GameService) -> Blueprint:
    """Create game routes blueprint."""

    game_blueprint = Blueprint("game_blueprint", __name__)
    mapper = WebGameMapper()

    @game_blueprint.post("/game/<string:game_id>")
    def update_game(game_id: str):
        try:
            parsed_game_id = UUID(game_id)
        except ValueError:
            return jsonify({"error": "Некорректный UUID игры."}), HTTPStatus.BAD_REQUEST

        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return (
                jsonify({"error": "Тело запроса должно быть JSON-объектом."}),
                HTTPStatus.BAD_REQUEST,
            )

        board = payload.get("board")
        if not isinstance(board, list):
            return jsonify({"error": "Поле 'board' обязательно."}), HTTPStatus.BAD_REQUEST

        try:
            request_model = CurrentGameRequest(board=board)
            current_game = mapper.to_domain(parsed_game_id, request_model)
            game_service.validate_game_board(current_game)

            result = game_service.check_game_finished(current_game)
            if not result.is_finished:
                current_game = game_service.get_next_move(current_game)
                result = game_service.check_game_finished(current_game)

            game_service.save_current_game(current_game)
            response_model = mapper.to_response(current_game, result)
            return jsonify(asdict(response_model)), HTTPStatus.OK
        except ValueError as error:
            return jsonify({"error": str(error)}), HTTPStatus.BAD_REQUEST

    return game_blueprint
