"""Domain <-> web mapping."""

from uuid import UUID

from domain.model.board import GameBoard
from domain.model.game import CurrentGame
from domain.model.game_result import GameResult
from web.model.game_request import CurrentGameRequest
from web.model.game_response import CurrentGameResponse


class WebGameMapper:
    """Map web DTOs to domain and back."""

    @staticmethod
    def to_domain(game_id: UUID, request_model: CurrentGameRequest) -> CurrentGame:
        return CurrentGame(game_id=game_id, board=GameBoard(cells=request_model.board))

    @staticmethod
    def to_response(
        current_game: CurrentGame,
        game_result: GameResult,
    ) -> CurrentGameResponse:
        return CurrentGameResponse(
            game_id=str(current_game.game_id),
            board=[row[:] for row in current_game.board.cells],
            is_finished=game_result.is_finished,
            winner=game_result.winner,
            message=game_result.message,
        )
