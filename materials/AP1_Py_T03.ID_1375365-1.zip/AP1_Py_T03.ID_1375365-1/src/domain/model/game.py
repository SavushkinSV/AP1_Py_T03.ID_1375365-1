"""Domain model for current game."""

from dataclasses import dataclass
from uuid import UUID

from domain.model.board import GameBoard


@dataclass(frozen=True)
class CurrentGame:
    """Current game aggregate."""

    game_id: UUID
    board: GameBoard
