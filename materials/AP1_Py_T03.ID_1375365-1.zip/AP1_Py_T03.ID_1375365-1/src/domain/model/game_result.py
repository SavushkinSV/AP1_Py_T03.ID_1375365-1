"""Domain model for game completion state."""

from dataclasses import dataclass


@dataclass(frozen=True)
class GameResult:
    """Computed game result for current board."""

    is_finished: bool
    winner: int | None
    message: str
