"""Domain model for tic-tac-toe board."""

from dataclasses import dataclass

BOARD_SIZE = 3
EMPTY_CELL = 0
USER_CELL = 1
COMPUTER_CELL = 2


@dataclass(frozen=True)
class GameBoard:
    """Represents a 3x3 board as integer matrix."""

    cells: list[list[int]]

    def user_moves_count(self) -> int:
        return sum(1 for row in self.cells for cell in row if cell == USER_CELL)

    def computer_moves_count(self) -> int:
        return sum(1 for row in self.cells for cell in row if cell == COMPUTER_CELL)

    def empty_cells(self) -> list[tuple[int, int]]:
        coordinates: list[tuple[int, int]] = []
        for row_idx, row in enumerate(self.cells):
            for col_idx, cell in enumerate(row):
                if cell == EMPTY_CELL:
                    coordinates.append((row_idx, col_idx))
        return coordinates

    def clone_cells(self) -> list[list[int]]:
        return [row[:] for row in self.cells]
