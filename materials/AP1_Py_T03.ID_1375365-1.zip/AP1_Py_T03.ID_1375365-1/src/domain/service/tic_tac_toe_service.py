"""Implementation of game service with minimax."""

from math import inf

from datasource.repository.game_repository import GameRepository
from domain.model.board import BOARD_SIZE, COMPUTER_CELL, EMPTY_CELL, USER_CELL, GameBoard
from domain.model.game import CurrentGame
from domain.model.game_result import GameResult
from domain.service.game_service import GameService


class TicTacToeService(GameService):
    """Service implementation that uses repository and minimax."""

    def __init__(self, game_repository: GameRepository) -> None:
        self._game_repository = game_repository

    def get_next_move(self, current_game: CurrentGame) -> CurrentGame:
        finished_state = self.check_game_finished(current_game)
        if finished_state.is_finished:
            return current_game

        board = current_game.board.clone_cells()
        best_score = -inf
        best_move: tuple[int, int] | None = None

        for row_idx, col_idx in self._empty_cells(board):
            board[row_idx][col_idx] = COMPUTER_CELL
            score = self._minimax(board, is_computer_turn=False)
            board[row_idx][col_idx] = EMPTY_CELL
            if score > best_score:
                best_score = score
                best_move = (row_idx, col_idx)

        if best_move is None:
            return current_game

        move_row, move_col = best_move
        board[move_row][move_col] = COMPUTER_CELL
        return CurrentGame(game_id=current_game.game_id, board=GameBoard(cells=board))

    def validate_game_board(self, current_game: CurrentGame) -> None:
        self._validate_board_shape_and_values(current_game.board)
        previous_game = self._game_repository.get_current_game(current_game.game_id)

        if previous_game is None:
            user_moves = current_game.board.user_moves_count()
            computer_moves = current_game.board.computer_moves_count()
            if user_moves != 1 or computer_moves != 0:
                raise ValueError(
                    "Для новой игры поле должно содержать ровно один ход игрока и ноль ходов компьютера."
                )
            return

        previous_result = self.check_game_finished(previous_game)
        if previous_result.is_finished:
            raise ValueError("Игра уже завершена, новые ходы недопустимы.")

        previous_cells = previous_game.board.cells
        current_cells = current_game.board.cells
        for row_idx in range(BOARD_SIZE):
            for col_idx in range(BOARD_SIZE):
                previous_cell = previous_cells[row_idx][col_idx]
                current_cell = current_cells[row_idx][col_idx]
                if previous_cell != EMPTY_CELL and previous_cell != current_cell:
                    raise ValueError("Обнаружено изменение ранее сделанного хода.")

        user_delta = (
            current_game.board.user_moves_count() - previous_game.board.user_moves_count()
        )
        computer_delta = (
            current_game.board.computer_moves_count()
            - previous_game.board.computer_moves_count()
        )
        if user_delta != 1:
            raise ValueError("Ожидается ровно один новый ход пользователя.")
        if computer_delta != 0:
            raise ValueError("Пользователь не может добавлять или изменять ходы компьютера.")

    def check_game_finished(self, current_game: CurrentGame) -> GameResult:
        winner = self._winner(current_game.board.cells)
        if winner is not None:
            if winner == USER_CELL:
                return GameResult(True, USER_CELL, "Победил пользователь.")
            return GameResult(True, COMPUTER_CELL, "Победил компьютер.")

        if len(current_game.board.empty_cells()) == 0:
            return GameResult(True, None, "Ничья.")

        return GameResult(False, None, "Игра продолжается.")

    def save_current_game(self, current_game: CurrentGame) -> None:
        self._game_repository.save_current_game(current_game)

    def _validate_board_shape_and_values(self, board: GameBoard) -> None:
        if len(board.cells) != BOARD_SIZE:
            raise ValueError("Игровое поле должно состоять из 3 строк.")
        for row in board.cells:
            if len(row) != BOARD_SIZE:
                raise ValueError("Каждая строка поля должна содержать 3 элемента.")
            for cell in row:
                if cell not in (EMPTY_CELL, USER_CELL, COMPUTER_CELL):
                    raise ValueError("Допустимые значения ячеек: 0, 1, 2.")

    def _winner(self, board: list[list[int]]) -> int | None:
        lines: list[list[int]] = []
        lines.extend(board)
        for col_idx in range(BOARD_SIZE):
            lines.append([board[row_idx][col_idx] for row_idx in range(BOARD_SIZE)])
        lines.append([board[idx][idx] for idx in range(BOARD_SIZE)])
        lines.append([board[idx][BOARD_SIZE - 1 - idx] for idx in range(BOARD_SIZE)])

        for line in lines:
            if line[0] != EMPTY_CELL and line[0] == line[1] == line[2]:
                return line[0]
        return None

    def _minimax(self, board: list[list[int]], is_computer_turn: bool) -> float:
        winner = self._winner(board)
        if winner == COMPUTER_CELL:
            return 1.0
        if winner == USER_CELL:
            return -1.0

        if not self._empty_cells(board):
            return 0.0

        if is_computer_turn:
            best_score = -inf
            for row_idx, col_idx in self._empty_cells(board):
                board[row_idx][col_idx] = COMPUTER_CELL
                score = self._minimax(board, is_computer_turn=False)
                board[row_idx][col_idx] = EMPTY_CELL
                best_score = max(best_score, score)
            return best_score

        best_score = inf
        for row_idx, col_idx in self._empty_cells(board):
            board[row_idx][col_idx] = USER_CELL
            score = self._minimax(board, is_computer_turn=True)
            board[row_idx][col_idx] = EMPTY_CELL
            best_score = min(best_score, score)
        return best_score

    def _empty_cells(self, board: list[list[int]]) -> list[tuple[int, int]]:
        result: list[tuple[int, int]] = []
        for row_idx in range(BOARD_SIZE):
            for col_idx in range(BOARD_SIZE):
                if board[row_idx][col_idx] == EMPTY_CELL:
                    result.append((row_idx, col_idx))
        return result
