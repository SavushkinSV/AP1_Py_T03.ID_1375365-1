"""Service interface for game logic."""

from abc import ABC, abstractmethod

from domain.model.game import CurrentGame
from domain.model.game_result import GameResult


class GameService(ABC):
    """Business operations required by assignment."""

    @abstractmethod
    def get_next_move(self, current_game: CurrentGame) -> CurrentGame:
        """Compute next move by minimax and return updated game."""

    @abstractmethod
    def validate_game_board(self, current_game: CurrentGame) -> None:
        """Validate that the board update from user is correct."""

    @abstractmethod
    def check_game_finished(self, current_game: CurrentGame) -> GameResult:
        """Return current completion state of a game."""

    @abstractmethod
    def save_current_game(self, current_game: CurrentGame) -> None:
        """Persist current game state."""
