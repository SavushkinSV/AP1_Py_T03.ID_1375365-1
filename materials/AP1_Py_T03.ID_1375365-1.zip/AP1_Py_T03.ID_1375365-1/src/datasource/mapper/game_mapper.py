"""Domain <-> datasource mapping."""

from uuid import UUID

from datasource.model.board_entity import BoardEntity
from datasource.model.game_entity import CurrentGameEntity
from domain.model.board import GameBoard
from domain.model.game import CurrentGame


class DatasourceGameMapper:
    """Mapper between domain and persistence models."""

    @staticmethod
    def to_entity(game: CurrentGame) -> CurrentGameEntity:
        return CurrentGameEntity(
            game_id=str(game.game_id),
            board=BoardEntity(cells=[row[:] for row in game.board.cells]),
        )

    @staticmethod
    def to_domain(entity: CurrentGameEntity) -> CurrentGame:
        return CurrentGame(
            game_id=UUID(entity.game_id),
            board=GameBoard(cells=[row[:] for row in entity.board.cells]),
        )
