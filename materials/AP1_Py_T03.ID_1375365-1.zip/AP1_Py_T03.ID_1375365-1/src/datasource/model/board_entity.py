"""Datasource model for board."""

from dataclasses import dataclass


@dataclass(frozen=True)
class BoardEntity:
    """Persistence board model."""

    cells: list[list[int]]
