"""Datasource model for current game."""

from dataclasses import dataclass

from datasource.model.board_entity import BoardEntity


@dataclass(frozen=True)
class CurrentGameEntity:
    """Persistence model keyed by game id."""

    game_id: str
    board: BoardEntity
