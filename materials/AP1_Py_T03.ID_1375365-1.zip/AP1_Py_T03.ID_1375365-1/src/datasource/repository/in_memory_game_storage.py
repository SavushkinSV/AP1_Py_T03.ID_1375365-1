"""Thread-safe in-memory storage for games."""

from threading import RLock

from datasource.model.game_entity import CurrentGameEntity


class InMemoryGameStorage:
    """Stores current games in a synchronized dictionary."""

    def __init__(self) -> None:
        self._storage: dict[str, CurrentGameEntity] = {}
        self._lock = RLock()

    def save(self, game: CurrentGameEntity) -> None:
        with self._lock:
            self._storage[game.game_id] = game

    def get(self, game_id: str) -> CurrentGameEntity | None:
        with self._lock:
            return self._storage.get(game_id)
