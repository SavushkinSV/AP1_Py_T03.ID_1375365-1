"""Repository interface for game storage."""

from abc import ABC, abstractmethod
from uuid import UUID

from domain.model.game import CurrentGame


class GameRepository(ABC):
    """Persistence operations for current games."""

    @abstractmethod
    def save_current_game(self, game: CurrentGame) -> None:
        """Save current game state."""

    @abstractmethod
    def get_current_game(self, game_id: UUID) -> CurrentGame | None:
        """Load current game state by id."""
