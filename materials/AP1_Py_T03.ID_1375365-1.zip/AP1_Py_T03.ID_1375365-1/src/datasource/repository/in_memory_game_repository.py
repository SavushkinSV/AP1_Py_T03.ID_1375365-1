"""In-memory repository implementation."""

from uuid import UUID

from datasource.mapper.game_mapper import DatasourceGameMapper
from datasource.repository.game_repository import GameRepository
from datasource.repository.in_memory_game_storage import InMemoryGameStorage
from domain.model.game import CurrentGame


class InMemoryGameRepository(GameRepository):
    """Repository based on thread-safe in-memory storage."""

    def __init__(self, storage: InMemoryGameStorage) -> None:
        self._storage = storage
        self._mapper = DatasourceGameMapper()

    def save_current_game(self, game: CurrentGame) -> None:
        entity = self._mapper.to_entity(game)
        self._storage.save(entity)

    def get_current_game(self, game_id: UUID) -> CurrentGame | None:
        entity = self._storage.get(str(game_id))
        if entity is None:
            return None
        return self._mapper.to_domain(entity)
