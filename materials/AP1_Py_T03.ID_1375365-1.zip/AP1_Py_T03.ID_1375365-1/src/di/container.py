"""DI container with dependency graph."""

from datasource.repository.in_memory_game_repository import InMemoryGameRepository
from datasource.repository.in_memory_game_storage import InMemoryGameStorage
from domain.service.game_service import GameService
from domain.service.tic_tac_toe_service import TicTacToeService


class Container:
    """Container with singleton storage and dependent services."""

    def __init__(self) -> None:
        self._storage_singleton = InMemoryGameStorage()
        self._repository = InMemoryGameRepository(self._storage_singleton)
        self._game_service = TicTacToeService(self._repository)

    @property
    def game_service(self) -> GameService:
        return self._game_service
