"""Application factory and Flask startup."""

from flask import Flask, send_from_directory

from di.container import Container
from web.module.game_module import register_game_module


def create_app() -> Flask:
    """Create configured Flask application."""

    app = Flask(__name__, static_folder="web/static", static_url_path="/static")
    container = Container()
    register_game_module(app, container.game_service)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host="0.0.0.0", port=5000, debug=True)
