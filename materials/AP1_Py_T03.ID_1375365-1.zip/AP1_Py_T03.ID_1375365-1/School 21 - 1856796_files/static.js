window.PRODUCT_VERSION = 'v81.0.0' || undefined;
window.KEYCLOAK_ENDPOINT = 'https://auth.21-school.ru/auth' || undefined;
window.SUPPORT_DOMAIN = 'support-s21.sp1.dmz.prod.sdp.21-school.ru' || undefined;
window.KEYCLOAK_CLIENT = 'school21' || undefined;
window.SENTRY_DSN = 'https://c3192afb22957372f9619b94aca17157@zentry.21-school.ru/2' || undefined;
window.GTM_ID = 'GTM-0000000' || undefined;
window.GITLAB_URL = 'https://git.21-school.ru' || undefined;
window.VIDEO_URL = 'https://sp1-cdn.sdp.21-school.ru/services/storage/download' || undefined;
